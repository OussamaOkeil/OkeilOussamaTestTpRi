/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.analyzetwitterdata ; 

/**
 *
 * @author ouss
 */
public class TweetsSavior {


public static void main(String[] args) {
		final String dbUrl = args[0];
		final String dbUser = args[1];
		final String dbPassword = args[2];
		final String location = args[3];
		final int numTrends = Integer.valueOf(args[4]);
		final int numTopHashtags = Integer.valueOf(args[5]);
		final String[] languages = args[6].split(",");
		final String[] moreKeywords = Arrays.copyOfRange(args, 7, args.length);
		final int interval = 15; //minutes

		TweetData tweetData = TweetDataFactory.create(dbUrl, dbUser, dbPassword);
		StreamHandler streamHandler = new StreamHandler( tweetData, location, interval, numTrends, numTopHashtags, languages, moreKeywords);
		addShutdownHook(tweetData, streamHandler);
  	  	streamHandler.run();
	}
	
	private static void addShutdownHook(TweetData tweetData, StreamHandler streamHandler) {
		Runtime.getRuntime().addShutdownHook(new Thread(()->
		{
			streamHandler.close();
			tweetData.close();		
			System.out.println("Cleanup work is done");
		}));
	}

}
