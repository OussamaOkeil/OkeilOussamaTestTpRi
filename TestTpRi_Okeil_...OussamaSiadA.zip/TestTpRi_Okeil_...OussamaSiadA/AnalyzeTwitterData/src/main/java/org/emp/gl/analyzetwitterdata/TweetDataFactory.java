/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.emp.gl.analyzetwitterdata;

/**
 *
 * @author ouss
 */
public class TweetDataFactory {

public static TweetData create(String url, String user, String password) {
		if (url.startsWith("bolt://") && user != null && password != null)
			return new TweetGraphData(url, user, password);
		else
			throw new IllegalArgumentException();
	}

}
