/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.emp.gl.analyzetwitterdata;

/**
 *
 * @author ouss
 */
public class StreamHandler {
public void run() {
		twitterStream = new TwitterStreamFactory().getInstance();
		twitterStream.onStatus(tweet->{
			tweetData.saveTweet(tweet);
			tweetCount++;        	
			updateScreen();
		});
		twitterStream.onException(e->e.printStackTrace());

		Set<String> keywords = null;
    	
		while ( !isDone ) {
			Set<String> updatedKeywords = getTrendsAndTopHashtags();
			updatedKeywords.addAll(moreKeywords);

			if (keywords == null || !keywords.containsAll(updatedKeywords) ) {
				if (keywords != null )
					twitterStream.cleanUp();

				System.out.printf( "Keywords: %s\n", updatedKeywords);
				FilterQuery query = new FilterQuery(updatedKeywords.toArray(new String[updatedKeywords.size()]));
				query.language(this.languages);
				twitterStream.filter(query);
			}
			try {
				Thread.sleep(refreshInterval*60*1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			keywords = updatedKeywords;
		}
	}
}
