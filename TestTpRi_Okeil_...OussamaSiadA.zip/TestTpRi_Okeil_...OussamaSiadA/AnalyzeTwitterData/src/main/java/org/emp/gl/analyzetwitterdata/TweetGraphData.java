/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.emp.gl.analyzetwitterdata;

/**
 *
 * @author ouss
 */
public class TweetGraphData implements TweetData  {

private ExecutorService execSvc;
	private GraphFacade graph;
	TweetGraphData(String url, String user, String password) {
		graph = GraphFacadeFactory.create(url, user, password);
		init();
	}
	protected ExecutorService getExecutorService() {
		if (execSvc == null) {
			execSvc = Executors.newSingleThreadExecutor(); 
		}
		return execSvc;
	}
	@Override
	public void saveTweet(Status tweet) {
    		this.getExecutorService().submit(new TweetGraphTask( tweet));
	}
	public void close() {
		graph.close();
		graph = null;
		System.out.println("Closed graph db connection");
		if (execSvc!=null) {
			execSvc.shutdown();
			try {
				execSvc.awaitTermination(10, TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			execSvc = null;
		}
	}
}
