package cfg;

import java.io.File;

public class Cfg
{
	public static String dataPath="data"+File.separator;
}
