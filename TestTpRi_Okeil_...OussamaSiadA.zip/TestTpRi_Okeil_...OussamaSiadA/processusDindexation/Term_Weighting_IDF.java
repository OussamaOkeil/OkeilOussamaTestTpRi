package OkeilOussama;

import java.io.IOException;
import static java.lang.Math.log;
import java.util.ArrayList;


public class Term_Weighting_IDF {
    public ArrayList<structure> index1 = new ArrayList<structure>();
    public ArrayList<structure> index2 = new ArrayList<structure>();
    public ArrayList<structure> index3 = new ArrayList<structure>();
    public ArrayList<structure> index4 = new ArrayList<structure>();
    public ArrayList<structure> index5 = new ArrayList<structure>();
    public ArrayList<structure> index6 = new ArrayList<structure>();
    public ArrayList<structure> index7 = new ArrayList<structure>();
    
    public int nbrOfDocument = 7;
    
    public ArrayList<structure1> index = new ArrayList<structure1>();
    public ArrayList<structure> index_generic = new ArrayList<structure>();
    
    public ArrayList<Documents> Documents = new ArrayList<>();
    public ArrayList<PostingListe> ps =new ArrayList<>();
    public save_index_to_disk gt = new save_index_to_disk();
    
    public void createIndex(String path, ArrayList<structure> index) throws IOException{
        //test Activity2
        Tokenization t = new Tokenization();
        t.tokenization(path);
        /*for(String str : t.list_of_tokens){
            System.out.println(str);
        }*/
        
        
        //test Activity3
        stopwords swr = new stopwords();
        swr.removeStopWord(t.list_of_tokens);
        /*for(String str : swr.list_of_tokens_without_stopwords){
            System.out.println(str);
        }*/
        
        
        //test Activity4
        Stemming st = new Stemming();
        st.stemming(swr.list_of_tokens_without_stopwords, 12);
        /*for(String str : st.list_of_stems){
            System.out.println(str);
        }
        System.err.println("****************************");*/
        
        //test Activity5
        Term_Weighting tw = new Term_Weighting();
        tw.term_Weighting_TF(st.list_of_stems,0);
        for(structure ds : tw.index_tab){
            //System.out.println(ds.stem + " ---> " + ds.nbocc + " ---> "  + ds.tf);
        }
        
        
        for(structure ds : tw.index_tab){
            index.add(ds);
        }
        
       
        
    } 
    
    
    
    public void index_collection(String path1,String path2,String path3,String path4,String path5,String path6,String path7) throws IOException{
        createIndex(path1, index1);
        createIndex(path2, index2);
        createIndex(path3, index3);
        createIndex(path4, index4);
        createIndex(path5, index5);
        createIndex(path6, index6);
        createIndex(path7, index7);
        
        
        //calculer le nombre d'occurence des element du doc 1 
        
        gt.DocIndex.put(1, path1);
        gt.DocIndex.put(2, path2);
        gt.DocIndex.put(3, path3);
        gt.DocIndex.put(4, path4);
        gt.DocIndex.put(5, path5);
        gt.DocIndex.put(6, path6);
        gt.DocIndex.put(7, path7);
        
        int i1=0;
        int ccc =0;
        
        for(structure ds1 : index1){
            ArrayList<Pairs> liste = new ArrayList<>();
            ArrayList<Integer> ll = new ArrayList<>();
            
            Pairs ppp = new Pairs();
            PostingListe p =new PostingListe();
            
            i1=i1+1;
            
            
            boolean b=false;
            int nbrOfDocWithCurrentStem = 1; 
            int nbrOccInTotal=ds1.nbocc; 
            ll.add(1);ll.add(ds1.nbocc);
            
            gt.TermIndex.put(ds1.stem,i1);
            for(structure ds2 : index2){
                if(ds1.stem.equals(ds2.stem)) {nbrOccInTotal=nbrOccInTotal+ds2.nbocc;nbrOfDocWithCurrentStem++;ll.add(2);ll.add(ds2.nbocc);break;} 
            }
           
            for(structure ds3 : index3){
                if(ds1.stem.equals(ds3.stem)) {nbrOccInTotal=nbrOccInTotal+ds3.nbocc;nbrOfDocWithCurrentStem++;ll.add(3);ll.add(ds3.nbocc); break;}
            }
            for(structure ds4 : index4){
                if(ds1.stem.equals(ds4.stem)) {nbrOccInTotal=nbrOccInTotal+ds4.nbocc;nbrOfDocWithCurrentStem++;ll.add(4);ll.add(ds4.nbocc); break;} 
            }
            for(structure ds5 : index5){
                if(ds1.stem.equals(ds5.stem)) {nbrOccInTotal=nbrOccInTotal+ds5.nbocc;nbrOfDocWithCurrentStem++;ppp.docid=5;ll.add(5);ll.add(ds5.nbocc);break; } 
            }
            for(structure ds6 : index6){
                if(ds1.stem.equals(ds6.stem)) {nbrOccInTotal=nbrOccInTotal+ds6.nbocc;nbrOfDocWithCurrentStem++;ll.add(6);ll.add(ds6.nbocc);break;} 
            }
            for(structure ds7 : index7){
                if(ds1.stem.equals(ds7.stem)) {nbrOccInTotal=nbrOccInTotal+ds7.nbocc;nbrOfDocWithCurrentStem++;ll.add(7);ll.add(ds7.nbocc);break; } 
            }
            
            
         
            for(structure1 i : index) {if(i.term.equals(ds1.stem)) b=true;}
            if(b==false){
                structure1 ds = new structure1();
                ds.term=ds1.stem;
                ds.nbrOfDocs=nbrOfDocWithCurrentStem;
                ds.freq=nbrOccInTotal;
                index.add(ds);
                //System.out.println(ds.term +" "+ ds.nbrOfDocs +" "+ ds.freq);
            } 
            ccc=ccc+1;
            p.termid=ccc;
            p.tabl=liste;
            ps.add(p);
            ds1.idf=log((double)7/nbrOfDocWithCurrentStem);
            ds1.doc=1;
            ds1.docs=nbrOfDocWithCurrentStem;
            gt.TermIndex.put(ds1.stem,ccc);
            gt.postingListIndex.put(ds1.stem, ll);
          
        }
        Documents ddd = new Documents();
        ddd.docid=1;
        ddd.docurl=path1;
        ddd.docsize=i1;
        Documents.add(ddd);
        
        //System.out.println(" documentid: "+ ddd.docid+" documentyrl: "+ddd.docurl+" documentsize: "+ddd.docsize);
        /*for(int m=0;m<ps.size();m++){
            System.out.println("id term " + ps.get(m).termid);
            for(int n=0 ;n<ps.get(m).tabl.size();n++)
                System.out.println("doc id "+ps.get(m).tabl.get(n).docid+"  "+"nb occ "+ps.get(m).tabl.get(n).nbocc);
        }*/
        //calculer le nombre d'occurence des element du doc 2 
        int i2=0;
        
        for(structure ds2 : index2){
            ArrayList<Pairs> liste = new ArrayList<>();
            ArrayList<Integer> ll = new ArrayList<>();
            
            Pairs ppp = new Pairs();
            PostingListe p =new PostingListe();
            i2=i2+1;
            boolean b=false;
            int nbrOfDocWithCurrentStem = 1;
            int nbrOccInTotal=ds2.nbocc;
            ll.add(2);
            ll.add(ds2.nbocc);
            for(structure ds1 : index1){
                if(ds2.stem.equals(ds1.stem)) {nbrOccInTotal=nbrOccInTotal+ds1.nbocc;nbrOfDocWithCurrentStem++;ll.add(1);ll.add(ds2.nbocc); break;}  
            }
            for(structure ds3 : index3){
                if(ds2.stem.equals(ds3.stem)) {nbrOccInTotal=nbrOccInTotal+ds3.nbocc;nbrOfDocWithCurrentStem++;ll.add(3);ll.add(ds3.nbocc); break;} 
            }
            for(structure ds4 : index4){
                if(ds2.stem.equals(ds4.stem)) {nbrOccInTotal=nbrOccInTotal+ds4.nbocc;nbrOfDocWithCurrentStem++;ll.add(4);ll.add(ds4.nbocc); break;} 
            }
            for(structure ds5 : index5){
                if(ds2.stem.equals(ds5.stem)) {nbrOccInTotal=nbrOccInTotal+ds5.nbocc;nbrOfDocWithCurrentStem++;ll.add(5);ll.add(ds5.nbocc); break;} 
            }
            for(structure ds6 : index6){
                if(ds2.stem.equals(ds6.stem)) {nbrOccInTotal=nbrOccInTotal+ds6.nbocc;nbrOfDocWithCurrentStem++;ll.add(6);ll.add(ds6.nbocc);break;} 
            }
            for(structure ds7 : index7){
                if(ds2.stem.equals(ds7.stem)) {nbrOccInTotal=nbrOccInTotal+ds7.nbocc;nbrOfDocWithCurrentStem++;ll.add(7);ll.add(ds7.nbocc);break;} 
            }
            ds2.idf=log((double)7/nbrOfDocWithCurrentStem);
            ds2.doc=2;
            ds2.docs=nbrOfDocWithCurrentStem;
            
            for(structure1 i : index) {if(i.term.equals(ds2.stem)) b=true;}
            if(b==false){
                structure1 ds = new structure1();
                ds.term=ds2.stem;
                ds.nbrOfDocs=nbrOfDocWithCurrentStem;
                ds.freq=nbrOccInTotal;
                index.add(ds);
                //System.out.println(ds.term +" "+ ds.nbrOfDocs +" "+ ds.freq);
            }
            ccc++;
            gt.TermIndex.put(ds2.stem,ccc);
            gt.postingListIndex.put(ds2.stem, ll);
        }
        
        Documents ddd2 = new Documents();
        ddd2.docid=2;
        ddd2.docurl=path2;
        ddd2.docsize=i2;
        Documents.add(ddd2);
        //calculer le nombre d'occurence des element du doc 3 
        int i3=0;
        ArrayList<Pairs> liste = new ArrayList<>();
        Pairs ppp = new Pairs();
        PostingListe p =new PostingListe();
        for(structure ds3 : index3){
            ArrayList<Integer> ll =new ArrayList<>();
            i3=i3+1;
            boolean b=false;
            int nbrOfDocWithCurrentStem = 1;
            int nbrOccInTotal=ds3.nbocc;
            ll.add(3);ll.add(ds3.nbocc);
            for(structure ds1 : index1){
                if(ds3.stem.equals(ds1.stem)) {nbrOccInTotal=nbrOccInTotal+ds1.nbocc;nbrOfDocWithCurrentStem++;ll.add(1);ll.add(ds1.nbocc); break;}  
            }
            for(structure ds2 : index2){
                if(ds3.stem.equals(ds2.stem)) {nbrOccInTotal=nbrOccInTotal+ds2.nbocc;nbrOfDocWithCurrentStem++;ll.add(2);ll.add(ds2.nbocc); break;} 
            }
            for(structure ds4 : index4){
                if(ds3.stem.equals(ds4.stem)) {nbrOccInTotal=nbrOccInTotal+ds4.nbocc;nbrOfDocWithCurrentStem++;ll.add(4);ll.add(ds4.nbocc); break;} 
            }
            for(structure ds5 : index5){
                if(ds3.stem.equals(ds5.stem)) {nbrOccInTotal=nbrOccInTotal+ds5.nbocc;nbrOfDocWithCurrentStem++;ll.add(5);ll.add(ds5.nbocc); break;} 
            }
            for(structure ds6 : index6){
                if(ds3.stem.equals(ds6.stem)) {nbrOccInTotal=nbrOccInTotal+ds6.nbocc;nbrOfDocWithCurrentStem++;ll.add(6);ll.add(ds6.nbocc); break;} 
            }
            for(structure ds7 : index7){
                if(ds3.stem.equals(ds7.stem)) {nbrOccInTotal=nbrOccInTotal+ds7.nbocc;nbrOfDocWithCurrentStem++;ll.add(7);ll.add(ds7.nbocc); break;} 
            }
            ds3.idf=log((double)7/nbrOfDocWithCurrentStem);
            ds3.doc=3;
            ds3.docs=nbrOfDocWithCurrentStem;
            
            for(structure1 i : index) {if(i.term.equals(ds3.stem)) b=true;}
            if(b==false){
                structure1 ds = new structure1();
                ds.term=ds3.stem;
                ds.nbrOfDocs=nbrOfDocWithCurrentStem;
                ds.freq=nbrOccInTotal;
                index.add(ds);
                //System.out.println(ds.term +" "+ ds.nbrOfDocs +" "+ ds.freq);
            }
            ccc++;
            gt.TermIndex.put(ds3.stem,ccc);
            gt.postingListIndex.put(ds3.stem, ll);
        }
        Documents ddd3 = new Documents();
        ddd3.docid=3;
        ddd3.docurl=path3;
        ddd3.docsize=i3;
        Documents.add(ddd3);
        //calculer le nombre d'occurence des element du doc 4 
        int i4=0;
        for(structure ds4 : index4){
            i4=i4+1;
            ArrayList<Integer> ll = new ArrayList<>();
            boolean b=false;
            int nbrOfDocWithCurrentStem = 1;
            int nbrOccInTotal=ds4.nbocc;
            ll.add(4);ll.add(ds4.nbocc);
            for(structure ds1 : index1){
                if(ds4.stem.equals(ds1.stem)) {nbrOccInTotal=nbrOccInTotal+ds1.nbocc;nbrOfDocWithCurrentStem++;ll.add(1);ll.add(ds1.nbocc); break;}  
            }
            for(structure ds2 : index2){
                if(ds4.stem.equals(ds2.stem)) {nbrOccInTotal=nbrOccInTotal+ds2.nbocc;nbrOfDocWithCurrentStem++; ll.add(2);ll.add(ds2.nbocc);break;} 
            }
            for(structure ds3 : index3){
                if(ds4.stem.equals(ds4.stem)) {nbrOccInTotal=nbrOccInTotal+ds4.nbocc;nbrOfDocWithCurrentStem++;ll.add(3);ll.add(ds3.nbocc); break;} 
            }
            for(structure ds5 : index5){
                if(ds4.stem.equals(ds5.stem)) {nbrOccInTotal=nbrOccInTotal+ds5.nbocc;nbrOfDocWithCurrentStem++;ll.add(5);ll.add(ds5.nbocc); break;} 
            }
            for(structure ds6 : index6){
                if(ds4.stem.equals(ds6.stem)) {nbrOccInTotal=nbrOccInTotal+ds6.nbocc;nbrOfDocWithCurrentStem++;ll.add(6);ll.add(ds6.nbocc); break;} 
            }
            for(structure ds7 : index7){
                if(ds4.stem.equals(ds7.stem)) {nbrOccInTotal=nbrOccInTotal+ds7.nbocc;nbrOfDocWithCurrentStem++;ll.add(7);ll.add(ds7.nbocc); break;} 
            }
            ds4.idf=log((double)7/nbrOfDocWithCurrentStem);
            ds4.doc=4;
            ds4.docs=nbrOfDocWithCurrentStem;
            
            for(structure1 i : index) {if(i.term.equals(ds4.stem)) b=true;}
            if(b==false){
                structure1 ds = new structure1();
                ds.term=ds4.stem;
                ds.nbrOfDocs=nbrOfDocWithCurrentStem;
                ds.freq=nbrOccInTotal;
                index.add(ds);
                //System.out.println(ds.term +" "+ ds.nbrOfDocs +" "+ ds.freq);
            }
            ccc++;
            gt.TermIndex.put(ds4.stem,ccc);
            gt.postingListIndex.put(ds4.stem, ll);
        }
        Documents ddd4 = new Documents();
        ddd4.docid=4;
        ddd4.docurl=path4;
        ddd4.docsize=i4;
        Documents.add(ddd4);
        //calculer le nombre d'occurence des element du doc 5 
        int i5=0;
        for(structure ds5 : index5){
            i5=i5+1; ArrayList<Integer> ll = new ArrayList<>();
            boolean b=false;
            int nbrOfDocWithCurrentStem = 1;
            int nbrOccInTotal=ds5.nbocc;
            ll.add(5);ll.add(ds5.nbocc);
            for(structure ds1 : index1){
                if(ds5.stem.equals(ds1.stem)) {nbrOccInTotal=nbrOccInTotal+ds1.nbocc;nbrOfDocWithCurrentStem++;ll.add(1);ll.add(ds1.nbocc); break;}  
            }
            for(structure ds2 : index2){
                if(ds5.stem.equals(ds2.stem)) {nbrOccInTotal=nbrOccInTotal+ds2.nbocc;nbrOfDocWithCurrentStem++;ll.add(2);ll.add(ds2.nbocc); break;} 
            }
            for(structure ds3 : index3){
                if(ds5.stem.equals(ds3.stem)) {nbrOccInTotal=nbrOccInTotal+ds3.nbocc;nbrOfDocWithCurrentStem++;ll.add(3);ll.add(ds3.nbocc); break;} 
            }
            for(structure ds4 : index4){
                if(ds5.stem.equals(ds4.stem)) {nbrOccInTotal=nbrOccInTotal+ds5.nbocc;nbrOfDocWithCurrentStem++;ll.add(4);ll.add(ds4.nbocc); break;} 
            }
            for(structure ds6 : index6){
                if(ds5.stem.equals(ds6.stem)) {nbrOccInTotal=nbrOccInTotal+ds6.nbocc;nbrOfDocWithCurrentStem++;ll.add(6);ll.add(ds6.nbocc); break;} 
            }
            for(structure ds7 : index7){
                if(ds5.stem.equals(ds7.stem)) {nbrOccInTotal=nbrOccInTotal+ds7.nbocc;nbrOfDocWithCurrentStem++;ll.add(7);ll.add(ds7.nbocc); break;} 
            }
            ds5.idf=log((double)7/nbrOfDocWithCurrentStem);
            ds5.doc=5;
            ds5.docs=nbrOfDocWithCurrentStem;
            
            for(structure1 i : index) {if(i.term.equals(ds5.stem)) b=true;}
            if(b==false){
                structure1 ds = new structure1();
                ds.term=ds5.stem;
                ds.nbrOfDocs=nbrOfDocWithCurrentStem;
                ds.freq=nbrOccInTotal;
                index.add(ds);
                //System.out.println(ds.term +" "+ ds.nbrOfDocs +" "+ ds.freq);
            }
            ccc++;
            gt.TermIndex.put(ds5.stem,ccc);
            gt.postingListIndex.put(ds5.stem, ll);
        }
        Documents ddd5 = new Documents();
        ddd5.docid=5;
        ddd5.docurl=path5;
        ddd5.docsize=i5;
        Documents.add(ddd5);
        //calculer le nombre d'occurence des element du doc 6 
        int i6=0; 
        
        for(structure ds6 : index6){
            i6=i6+1;
            ArrayList<Integer> ll = new ArrayList<>();
            boolean b=false;
            int nbrOfDocWithCurrentStem = 1;
            int nbrOccInTotal=ds6.nbocc;
            ll.add(6);ll.add(ds6.nbocc);
            for(structure ds1 : index1){
                if(ds6.stem.equals(ds1.stem)) {nbrOccInTotal=nbrOccInTotal+ds1.nbocc;nbrOfDocWithCurrentStem++;ll.add(1);ll.add(ds1.nbocc); break;}  
            }
            for(structure ds2 : index2){
                if(ds6.stem.equals(ds2.stem)) {nbrOccInTotal=nbrOccInTotal+ds2.nbocc;nbrOfDocWithCurrentStem++;ll.add(2);ll.add(ds2.nbocc); break;} 
            }
            for(structure ds3 : index3){
                if(ds6.stem.equals(ds3.stem)) {nbrOccInTotal=nbrOccInTotal+ds3.nbocc;nbrOfDocWithCurrentStem++;ll.add(3);ll.add(ds3.nbocc);break;} 
            }
            for(structure ds4 : index4){
                if(ds6.stem.equals(ds4.stem)) {nbrOccInTotal=nbrOccInTotal+ds4.nbocc;nbrOfDocWithCurrentStem++;ll.add(4);ll.add(ds4.nbocc); break;} 
            }
            for(structure ds5 : index5){
                if(ds6.stem.equals(ds5.stem)) {nbrOccInTotal=nbrOccInTotal+ds5.nbocc;nbrOfDocWithCurrentStem++;ll.add(5);ll.add(ds5.nbocc); break;} 
            }
            for(structure ds7 : index7){
                if(ds6.stem.equals(ds7.stem)) {nbrOccInTotal=nbrOccInTotal+ds7.nbocc;nbrOfDocWithCurrentStem++;ll.add(7);ll.add(ds7.nbocc); break;} 
            }
            ds6.idf=log((double)7/nbrOfDocWithCurrentStem);
            ds6.doc=6;
            ds6.docs=nbrOfDocWithCurrentStem;
            
            for(structure1 i : index) {if(i.term.equals(ds6.stem)) b=true;}
            if(b==false){
                structure1 ds = new structure1();
                ds.term=ds6.stem;
                ds.nbrOfDocs=nbrOfDocWithCurrentStem;
                ds.freq=nbrOccInTotal;
                index.add(ds);
                //System.out.println(ds.term +" "+ ds.nbrOfDocs +" "+ ds.freq);
            }
            ccc++;
            gt.TermIndex.put(ds6.stem,ccc);
            gt.postingListIndex.put(ds6.stem, ll);
        }
        Documents ddd6 = new Documents();
        ddd6.docid=6;
        ddd6.docurl=path6;
        ddd6.docsize=i6;
        Documents.add(ddd6);
        //calculer le nombre d'occurence des element du doc 7 
        int i7=0;
        for(structure ds7 : index7){
            i7=i7+1;
            ArrayList<Integer> ll = new ArrayList<>();
            boolean b=false;
            int nbrOfDocWithCurrentStem = 1;
            int nbrOccInTotal=ds7.nbocc;
            ll.add(7);ll.add(ds7.nbocc);
            for(structure ds1 : index1){
                if(ds7.stem.equals(ds1.stem)) {nbrOccInTotal=nbrOccInTotal+ds1.nbocc;nbrOfDocWithCurrentStem++;ll.add(1);ll.add(ds1.nbocc); break;}  
            }
            for(structure ds2 : index2){
                if(ds7.stem.equals(ds2.stem)) {nbrOccInTotal=nbrOccInTotal+ds2.nbocc;nbrOfDocWithCurrentStem++;ll.add(2);ll.add(ds2.nbocc); break;} 
            }
            for(structure ds3 : index3){
                if(ds7.stem.equals(ds3.stem)) {nbrOccInTotal=nbrOccInTotal+ds3.nbocc;nbrOfDocWithCurrentStem++;ll.add(3);ll.add(ds3.nbocc); break;} 
            }
            for(structure ds4 : index4){
                if(ds7.stem.equals(ds4.stem)) {nbrOccInTotal=nbrOccInTotal+ds4.nbocc;nbrOfDocWithCurrentStem++; ll.add(4);ll.add(ds4.nbocc);break;} 
            }
            for(structure ds5 : index5){
                if(ds7.stem.equals(ds5.stem)) {nbrOccInTotal=nbrOccInTotal+ds5.nbocc;nbrOfDocWithCurrentStem++;ll.add(5);ll.add(ds5.nbocc); break;} 
            }
            for(structure ds6 : index6){
                if(ds7.stem.equals(ds6.stem)) {nbrOccInTotal=nbrOccInTotal+ds6.nbocc;nbrOfDocWithCurrentStem++;ll.add(6);ll.add(ds6.nbocc); break;} 
            }
            ds7.idf=log((double)7/nbrOfDocWithCurrentStem);
            ds7.doc=7;
            ds7.docs=nbrOfDocWithCurrentStem;
            
            for(structure1 i : index) {if(i.term.equals(ds7.stem)) b=true;}
            if(b==false){
                structure1 ds = new structure1();
                ds.term=ds7.stem;
                ds.nbrOfDocs=nbrOfDocWithCurrentStem;
                ds.freq=nbrOccInTotal;
                index.add(ds);
                //System.out.println(ds.term +" "+ ds.nbrOfDocs +" "+ ds.freq);
            }
            ccc++;
            gt.TermIndex.put(ds7.stem,ccc);
            gt.postingListIndex.put(ds7.stem, ll);
        }
        Documents ddd7 = new Documents();
        ddd7.docid=7;
        ddd7.docurl=path7;
        ddd7.docsize=i7;
        Documents.add(ddd7);
        gt.Init_Term_Index_on_Memory(gt.TermIndex);
        gt.Init_Doc_Index_on_Memory(gt.DocIndex);
        gt.Init_Posting_List_on_Memory(gt.postingListIndex);
        
        //System.out.println(gt.TermIndex);
        //for(Documents w:Documents)
           // System.out.println(" documentid: "+ w.docid+" documentyrl: "+w.docurl+" documentsize: "+w.docsize);
    }
   
}

