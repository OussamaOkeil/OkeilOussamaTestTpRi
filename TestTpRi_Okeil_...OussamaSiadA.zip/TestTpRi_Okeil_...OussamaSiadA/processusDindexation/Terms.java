package OkeilOussama;


public class Terms {
    public int termid ;
    public String termstring ;
    
}
