package OkeilOussama;



class Struct_list_info {
    public int doc;
    public int occ;
    
}
