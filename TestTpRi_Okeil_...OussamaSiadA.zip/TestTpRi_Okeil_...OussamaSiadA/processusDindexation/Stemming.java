package OkeilOussama;

import java.util.ArrayList;


public class Stemming {
    public ArrayList<String> list_of_stems = new ArrayList<String>();
    
    public void stemming(ArrayList<String> L,int size){
        for(String str : L){
            if(str.length()>size){
                list_of_stems.add(str.substring(0, size));
            }
            
            else list_of_stems.add(str);
        }
    }
    
}
