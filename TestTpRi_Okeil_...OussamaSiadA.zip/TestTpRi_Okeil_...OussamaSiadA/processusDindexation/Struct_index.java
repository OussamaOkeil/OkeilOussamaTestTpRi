package OkeilOussama;


import java.util.ArrayList;
import java.util.List;

import OkeilOussama.Struct_list_info;


class Struct_index {
    public String term;
    public int termID;
    public int Docs;
    public List<Struct_list_info> info = new ArrayList<Struct_list_info>(); 
    
    
}
