package OkeilOussama;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

 //------- ACTIVITY 1 -----  



public class save_index_to_disk {
    public HashMap<String, Integer> TermIndex = new HashMap<>();
    public HashMap<Integer, String> DocIndex = new HashMap<>(); 
    public HashMap<String, ArrayList<Integer>> postingListIndex = new HashMap<>() ;
    public HashMap<String, Integer> docsOfTerm = new HashMap<>();
    
    public void Read_Term_Index_in_Memory(String path) throws FileNotFoundException, IOException{
        DataInputStream dis = new DataInputStream(new FileInputStream(path));
        
        while(dis.available() > 0){
            String s = dis.readUTF();
            int i = dis.readInt();
            TermIndex.put(s,i);
        }
    }
    
   
    
    public void Read_Doc_Index_in_Memory(String path) throws FileNotFoundException, IOException{
        DataInputStream dis = new DataInputStream(new FileInputStream(path));
        
        while(dis.available() > 0){
            int i = dis.readInt();
            String s = dis.readUTF();
            
            DocIndex.put(i, s);
        }
    }
    
    public void Read_PostingList_Index_in_Memory(String path) throws FileNotFoundException, IOException{
        DataInputStream dis = new DataInputStream(new FileInputStream(path));
        
        while(dis.available() > 0){
            ArrayList<Integer> l = new ArrayList<Integer>();
            
            int termID = dis.readInt();
            Integer term = TermIndex.get(termID);
            
            int docs = dis.readInt();
            
           
        }
    }
    
    public void Init_Term_Index_on_Memory(HashMap<String, Integer> table) throws FileNotFoundException, IOException{
        
        DataOutputStream dos = new DataOutputStream(new FileOutputStream("term.idx"));
        for(String i :table.keySet()){
            dos.writeUTF(i);
            dos.writeInt(table.get(i));
           
        }
    }
    
    
    
    public void Init_Doc_Index_on_Memory(HashMap<Integer, String> table) throws FileNotFoundException, IOException{
        
        
        DataOutputStream dos = new DataOutputStream(new FileOutputStream("doc.idx"));
        for(int i :table.keySet()){
            dos.writeUTF(table.get(i));
            dos.writeInt(i);
           
        }
    }
    
    
    public void Init_Posting_List_on_Memory(HashMap<String, ArrayList<Integer>> table) throws FileNotFoundException, IOException{
        DataOutputStream dos = new DataOutputStream(new FileOutputStream("pstinglist.idx"));
        for(String i :table.keySet()){
            dos.writeUTF(i);
            for(int j=0;j< table.get(i).size();j++)
                dos.writeInt(table.get(i).get(j));
            

           
        }
    }
   
}
