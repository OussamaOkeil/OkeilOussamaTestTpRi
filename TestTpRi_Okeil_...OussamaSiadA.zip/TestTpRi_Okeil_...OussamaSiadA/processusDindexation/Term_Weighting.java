package OkeilOussama;

import static java.lang.Math.log;
import java.util.ArrayList;
 
    public class Term_Weighting {
    public ArrayList<structure> index_tab = new ArrayList<structure>();
    public ArrayList<String> temp = new ArrayList<String>();
    public ArrayList<Terms> Terms = new ArrayList<>();
    public int id=0;
    
    public void term_Weighting(ArrayList<String> L, ArrayList<Terms> Terms){
        int occ=0;
        for(String str : L){
            occ=0;
            if(temp.contains(str)==false){
                temp.add(str);
                id=id+1;
                for(String str1 : L){
                    if(str.equals(str1)) occ++;
                }
                structure ds = new structure();
                ds.stem=str;
                ds.nbocc=occ;
                index_tab.add(ds);
                Terms tt =new Terms();
                tt.termid=id;
                tt.termstring=str;
                Terms.add(tt);
                //System.out.println(tt.termid+" "+tt.termstring);
                //System.out.println("term : " +ds.stem +" nbrocc : "+ ds.nbocc);
            }
        }
    }
    public void term_Weighting_TF(ArrayList<String> L, int numDoc){
        int occ=0;
        float tf=0;
        for(String str : L){
            occ=0;
            if(temp.contains(str)==false){
                temp.add(str);
                
                for(String str1 : L){
                    if(str.equals(str1)) occ++;
                }
                structure ds = new structure();
                ds.stem=str;
                ds.nbocc=occ;
                tf=(float) (1+log(occ));
                ds.tf=tf;
                ds.doc=numDoc;
                index_tab.add(ds);
                
                //System.out.println("term : " +ds.stem +" nbrocc : "+ ds.nbocc + "term : " +ds.stem +" nbrocc : "+ ds.nbocc);
            }
        }
    }
    
}
