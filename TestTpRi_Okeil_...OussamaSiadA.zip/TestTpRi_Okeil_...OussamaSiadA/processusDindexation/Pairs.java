package OkeilOussama;


public class Pairs {
    public int docid;
    public int nbocc;
    
}
