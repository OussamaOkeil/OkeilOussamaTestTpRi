package OkeilOussama;

import java.util.ArrayList;


public class PostingListe {
    public int termid ;
    public ArrayList<Pairs> tabl ;
    
}
