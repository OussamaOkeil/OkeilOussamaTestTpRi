package OkeilOussama;


public class structure1 {
    public String term;
    public int nbrOfDocs;
    public int freq;
    
}
