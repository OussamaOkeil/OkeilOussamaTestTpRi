package OkeilOussama;

import java.util.ArrayList;
import java.util.StringTokenizer;


public class Tokenization {
    public ArrayList<String> list_of_tokens = new ArrayList<String>();
    
    public void test(){
        String msg = "http://172.16.1.140:8080/";
        StringTokenizer st = new StringTokenizer(msg,"://.");
        while(st.hasMoreTokens()){
            System.out.println(st.nextToken());
        }
    }
    
    public void tokenization(String path){
        
        Lecture rff= new Lecture();
        rff.readFromFile1(path);
         String myText = rff.text;
         
         
         StringTokenizer st = new StringTokenizer(myText,", .'()-\t\n,0123456789");
         
         while(st.hasMoreTokens()){
             list_of_tokens.add(st.nextToken());
         }
         for(String str : list_of_tokens){
             if(str.equals(" ")) list_of_tokens.remove(str);
         }
         //for(String str : list_of_tokens){
             //System.out.println(str);
    
         }
    
}
