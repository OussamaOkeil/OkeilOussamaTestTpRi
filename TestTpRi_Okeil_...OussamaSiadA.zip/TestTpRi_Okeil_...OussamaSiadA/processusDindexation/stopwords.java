package OkeilOussama;

import java.util.ArrayList;
import java.util.StringTokenizer;



public class stopwords {
    public ArrayList<String> list_of_tokens_without_stopwords = new ArrayList<>();
    public ArrayList<String> list_of_stopWords = new ArrayList<>();
    public boolean exist = false;
    
    public void removeStopWord(ArrayList<String> L){
         Lecture rff = new Lecture();
         rff.readFromFile1("stopwords.txt");
         String myText = rff.text;
         
         StringTokenizer st = new StringTokenizer(myText);
         while(st.hasMoreTokens()){
             list_of_stopWords.add(st.nextToken());
         }
         
         for(String str : L){
             exist=false;
             for(String str1 : list_of_stopWords){
                 if(str.equals(str1)) {exist =true; break;}
             }
             if(exist==false) {list_of_tokens_without_stopwords.add(str);
             //System.out.println(str);}
         }
    }
    
}
}

