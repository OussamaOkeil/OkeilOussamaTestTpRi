
package OkeilOussama;



import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;



public class Lecture {
    public String text = new String();
    
    public void readFromFile(String path) throws FileNotFoundException, IOException {
        BufferedReader br = new BufferedReader(new FileReader(path));
        try {
               
               while ((text=br.readLine()) != null) {
                     System.out.println(text);
               }
            } finally {
            br.close();
            }
    
}
    public void readFromFile1(String path) {
        
        try{
        Scanner myScanner = new Scanner(new File(path));
                
        String line = new String("_");
        
        while(myScanner.hasNext()){
            line = myScanner.next();
            text += "\n" + line;
        }
        myScanner.close();
        //System.out.println(text);
        }
        catch(FileNotFoundException expNFF){
            expNFF.getMessage();
        }
        
    }
}
