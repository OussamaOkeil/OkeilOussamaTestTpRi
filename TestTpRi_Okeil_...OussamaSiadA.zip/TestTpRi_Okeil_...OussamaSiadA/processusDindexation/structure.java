package OkeilOussama;


public class structure {
    public String stem;
    public int nbocc;
    public float tf;
    public int doc;
    public int docs;
    public double idf ;
    
}
