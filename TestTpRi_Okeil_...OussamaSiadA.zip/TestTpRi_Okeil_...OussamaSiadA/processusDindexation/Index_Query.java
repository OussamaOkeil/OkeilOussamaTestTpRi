package OkeilOussama;



import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import static java.lang.Math.log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;


public class Index_Query {
    
    
    public List<String> tokens_list = new ArrayList<>();
    public List<String> list_of_tokens_without_stopwords = new ArrayList<String>();
    public List<String> list_of_stopWords = new ArrayList<String>();
    public List<String> list_of_stems = new ArrayList<String>();
    
    public HashMap<String, ArrayList<Integer>> Posting_List_of_Query_on_Memory_step_1 = new HashMap<>() ;
    
    
    public boolean exist = false;
    
    public void tokenization(String query){
       
        StringTokenizer st = new StringTokenizer(query,", .'()-\t\n,");
        
        while(st.hasMoreTokens()){
             tokens_list.add(st.nextToken());
        }
    }
    
    public void removeStopWord(List<String> L){
         Lecture rff = new Lecture();
         rff.readFromFile1("stopwords.txt");
         String myText = rff.text;
         
         StringTokenizer st = new StringTokenizer(myText);
         while(st.hasMoreTokens()){
             list_of_stopWords.add(st.nextToken());
         }
         
         for(String str : L){
             exist=false;
             for(String str1 : list_of_stopWords){
                 if(str.equals(str1)) {exist =true; break;}
             }
             if(exist==false) list_of_tokens_without_stopwords.add(str);
         }
    }
    
    public void stemming(List<String> L,int size){
        for(String str : L){
            if(str.length()>size){
                list_of_stems.add(str.substring(0, size));
            }
            
            else list_of_stems.add(str);
        }
    }
    
    public void step1(HashMap<String, ArrayList<Integer>> indexHashMap){
        
        for(String str : list_of_stems){
            ArrayList<Integer> l = new ArrayList<Integer>();
            l=indexHashMap.get(str);
            
            Posting_List_of_Query_on_Memory_step_1.put(str, l);
        }
        
    }
    public void Init_Posting_List_of_Query_on_Memory(HashMap<String, ArrayList<Integer>> table) throws FileNotFoundException, IOException{
        DataOutputStream dos = new DataOutputStream(new FileOutputStream("query.idx"));
        for(String i :table.keySet()){
            dos.writeUTF(i);
            for(int j=0;j< table.get(i).size();j++)
                dos.writeInt(table.get(i).get(j));
            

           
        }
    }
    
    
    
}
