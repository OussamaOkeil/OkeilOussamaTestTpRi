
package OkeilOussama;


public class Documents {
    public int docid ;
    public String docurl ;
    public int docsize ;
    
    
}
