/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package twitter_example_for_students;

/**
 *
 * @author ouss
 */
public class MethodeAndPropreties {

public class Methods_and_Properties {
    Extractor e = new Extractor();
    Twitter_Example_for_Students twitter = new Twitter_Example_for_Students();
    public ArrayList<String> extractMentions(String text) {
        
        ArrayList<String> mentions = (ArrayList<String>) e.extractMentionedScreennames(text, true);
        return mentions;
    }

    public ArrayList<String> extractLiens(String text) {
       
        ArrayList<String> extractedMentions = (ArrayList<String>) e.extractURLs(text);
        return extractedMentions;
    }

    public ArrayList<String> extractHashtags(String text) {
       
        ArrayList<String> extractedMentions = (ArrayList<String>) e.extractHashtags(text, true);
        return extractedMentions;
    }

}
